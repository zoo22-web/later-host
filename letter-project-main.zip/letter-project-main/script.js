const message = `I wanna say thank you for coming into my life.\nfor making me smile and laugh… I just want you to know, I still think about you cause you are the my special person.\n\nthank you so much for being understand. meeting you was like will always be one of the best part. But i for all my mistakes, i never want to hurt you .”\n\nim trying for you but sometimes i fail but i will try my best, im scared of losing you … im so sorry you had to meet me, its okay to be tired, but never give up,\n\nAnyway, thank you and sorry for everthing.`;

function showLetter() {
  document.getElementById("introText").style.opacity = 0;
  document.querySelector(".btn").style.display = "none";

  setTimeout(() => {
    const letterBox = document.getElementById("letterBox");
    const typedText = document.getElementById("typedText");
    letterBox.style.display = "block";
    let i = 0;

    function typeWriter() {
      if (i < message.length) {
        typedText.innerHTML += message.charAt(i);
        i++;
        setTimeout(typeWriter, 30);
      }
    }

    typeWriter();
  }, 600);
}
